.pio/compare/benchmark_core.c.o: \
 /Users/manu/deftio/qf_math/compare/benchmark_core.c \
 /Users/manu/deftio/qf_math/compare/benchmark_core.h \
 /Users/manu/deftio/qf_math/build/compare/third_party/fr_math/src/FR_math.h \
 /Users/manu/deftio/qf_math/build/compare/third_party/fr_math/src/FR_defs.h \
 /Users/manu/deftio/qf_math/build/compare/third_party/libfixmath/libfixmath/fix16.h \
 /Users/manu/deftio/qf_math/src/qf_math.h
