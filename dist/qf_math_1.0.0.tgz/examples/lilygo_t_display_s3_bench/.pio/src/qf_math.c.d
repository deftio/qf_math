.pio/src/qf_math.c.o: /Users/manu/deftio/qf_math/src/qf_math.c \
 /Users/manu/deftio/qf_math/src/qf_math.h
